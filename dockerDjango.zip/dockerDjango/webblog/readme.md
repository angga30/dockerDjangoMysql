# ini django project blog opwn
